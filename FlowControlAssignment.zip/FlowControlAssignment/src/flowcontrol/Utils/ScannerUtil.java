package flowcontrol.Utils;

import java.util.Scanner;

public class ScannerUtil {
	private static Scanner scanner = new Scanner (System.in);
	
	public static Scanner getScanner() {
		return scanner;
	}
};
